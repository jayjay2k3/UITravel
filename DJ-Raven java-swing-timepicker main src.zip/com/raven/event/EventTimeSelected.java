package com.raven.event;

public interface EventTimeSelected {

    public void hourSelected(int hour);

    public void minuteSelected(int minute);
}
