package com.raven.event;

public interface EventTimeChange {

    public void timeChange(boolean isHour);
}
