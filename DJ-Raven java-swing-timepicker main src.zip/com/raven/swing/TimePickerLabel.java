package com.raven.swing;

import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

public class TimePickerLabel extends JLabel {

    public TimePickerLabel() {
        setBorder(new EmptyBorder(5, 0, 5, 0));
    }
}
