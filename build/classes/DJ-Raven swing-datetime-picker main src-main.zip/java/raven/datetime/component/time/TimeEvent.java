package raven.datetime.component.time;

import java.util.EventObject;

public class TimeEvent extends EventObject {

    public TimeEvent(Object source) {
        super(source);
    }
}
