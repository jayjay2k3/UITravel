package raven.datetime.component.date;

import java.util.EventObject;

public class DateEvent extends EventObject {

    public DateEvent(Object source) {
        super(source);
    }
}
