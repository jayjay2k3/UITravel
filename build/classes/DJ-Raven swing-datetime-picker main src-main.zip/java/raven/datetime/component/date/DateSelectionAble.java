package raven.datetime.component.date;

import java.time.LocalDate;

public interface DateSelectionAble {
    boolean isDateSelectedAble(LocalDate date);
}
